console.log("hello world");
console.log("한글테스트");

//카멜표기법.  소문자로 시작. 연결된단어의 첫글자마다 대문자를 붙여줌.
//자바스크립트에서는 값이 변수에 대입될때 데이터타입이 정해진다.
//컴파일언어가 아니라 인터프리터 언어기때문에 한줄한줄 그때 실행한다.
var myAge = 15;
let brotherAge = 20;
// console.log(myAge+brotherAge);

// console.log(35);    //하드코딩. 이 경우 밖에 못쓴다. 유연성이 없다.


let a = null;
let b;
let c = true;
let d = 15;

let e = "십육";
//마이너스, 영어, 숫자와 영어를 섞으면

console.log(typeof a); //object. null이 아니라 object로 나오고있다.
console.log(typeof b); //undefined
console.log(typeof c); //boolean
console.log(typeof d); //number
console.log(typeof e); //string

//문자열과 숫자를 더하게 되면 문자열로 합쳐진다.
//NaN = Not a Number //숫자가 아니라서 연산을 할 수없다.

let x = 123;
let y = "456";
let z = y+100; //456100. 45만 6100을 의미하는게 아니다.

console.log(15+15.55);
console.log(15-4.5);
console.log(10/3);      //3.3333333333333335
console.log(15*4.5);


//부동소수점
let realX = 3.0;
let realY = 5.0;
console.log((realX / realY)+0.4);

// let 변수명;     //변수의 선언
// 변수명 = 값;    //값 할당
// let 변수명2 = 값;    //초기화. 초기값을 세팅해준다.

//조건문
if(x>=100){
    console.log("x는 100이상입니다.");
}else{
    console.log("x는 100보다 작습니다.");
}

if(realX==3.0){
    console.log("참입니다.");
}else{
    console.log("거짓입니다.");
}


//실습1.
// mydata라는 변수를 선언하고
// 그 변수의 타입이 문자열이면 해당변수는 문자열입니다.
// 라고 콘솔에 표현하고,
// 숫자면 숫자입니다. 를 표현하고
// 나머지면 나머지입니다.를 표현해보세요.
// => 문제를 쪼개야된다.
// 1. 변수초기화(선언과 값 할당)
// 2. 변수의 데이터타입 추출해보기
// 3. 추출한 데이터타입의 분기처리

let myData = "Dd";
if(typeof myData=="string"){
    console.log("해당 변수는 문자입니다.");
}else if(typeof myData=="number"){
    console.log("해당 변수는 숫자입니다.");
}
else{
    console.log("나머지 입니다.");
}
//else는 자기와 가장 가까운 if의 나머지로 붙는다.


let num = 1001;
//num **= 2;
let result = num % 6;
console.log(result);

//숫자가담긴 변수를 주면
//그 숫자가 짝수인지 홀수인지 판별해서 콘솔로 출력해보세요.
//1. 짝수와 홀수를 어떻게 구별할수 있을지 생각
    //짝수는 무엇이고 홀수는 무엇인가
    // 나는 어떻게 짝수 홀수를 구별하고있었지?
if(num%2 == 0){
    console.log("짝수");
}else{
    console.log("홀수");
}

//4의 배수인지 아닌지를 구별해보세요.
//4의 배수는 어떤게 구별할까? 일반화시킨것을 코딩
//4로나눈 나머지가 0이면 4의 배수다.
let number1 = 12348;
if(number1 %4 == 0){
    console.log("해당변수는 4의 배수입니다.");
}else{
    console.log("해당변수는 4의 배수가 아닙니다.");
}

number1 = number1+1;    //12349
number1 += 1;   //12350
console.log(number1++);  //변수의값을 활용한다음 증가. 12350이 출력되고 값은 12351이됨
console.log(++number1);  //증가한다음 값을 활용. 12352가 출력되고 값은 이미 증가됨.
console.log(number1);    //12352


let g = 5;
// let h = g-- + 2 + --g;

// 5를 쓰고 1을 더함
// 거기에 2를 더함
// 4에서 1을뺀값을 씀.
// //5 + 2 + 3 = 10
    // 앞에붙으면 사용전에 연산
    // 뒤에붙으면 사용후에 연산
let h = ++g + g++ + g;  //6+6+7
console.log(1,2,3,4,5);

console.log("h : ", h);
console.log("h : "+ h);

let hhh = 0;
debugger;
if(hhh-- < 0){  //비교연산자보다 증감연산자가 먼저
                //구글링해보니 비교연산자10, 후위증감16
    console.log("hhh는 현재 음수");
    console.log("현재 hhh값 : ", hhh);
}else if (hhh == 0){
    console.log('hhh는 현재 0');
    console.log("현재 hhh값 : ", hhh);
}else{
    console.log('hhh는 현재 양수');
    console.log("현재 hhh값 : ", hhh);
}


let fNum = 350;
if(fNum % 5==0 && fNum<100){
    console.log("fNum은 5의배수이며 100이하");
}

//변수가 3또는 5의 배수, 단 15의 배수는 아닐때만
//내가 찾는수 라고 콘솔에 표현
//  () 묶음처리


let myNum5 = 30;
if((myNum5 % 3==0 || myNum5 % 5==0) && !(myNum5 % 15==0) ) {
    console.log("내가 찾는 수");
}else{
    console.log("그 외");
}

// 변수 3개가 있을때
// 그중에 가장 큰수를 출력해보세요.
        // 한글로 어떻게 코딩을 할지 먼저 설계.
        // 그 한글을 코드로 바꾸면된다.
let n1 = 5;
let n2 = 100;
let n3 = -20;
   //최대값을 저장할 변수 선언하고 아무변수나 하나 집어넣음
//테스트. 세개다 음수일때, 소수넣어서 테스트, 3개다 값이 같을때
let num1 = 342;
let num2 = 240;
let num3 = 841;
let max = num1;
if(num2 >= max){    //num2가 더 크면 num2로 최대값 교체
    max = num2;
}
if(num3 >= max){    //교체된 max보다 num3이 더크면 num3으로 교체
    max = num3;
}
console.log(max);

//위의 3개변수의 평균값을 구해보세요.
let avg = (num1+num2+num3)/3;
console.log(avg);


//let month 에는  1월 12월까지가 들어올거다.
//들어온 월에 해당하는 계절을 출력해보세요.
// 3~5 : 봄
// 6~8 : 여름
// 9~11 : 가을
// 12~2 : 겨울
// 봄은 3으로 나눈 몫이 1   여름은2, 가을은3,  겨울은4또는0
let month = 15;
if(3<=month && month<=5){
    console.log("봄");
}
else if(6<=month && month<=8){
    console.log("여름");
}
else if(9<=month && month<=11){
    console.log("가을")
}
else if(12<=month && month<=12){
    console.log("겨울")
}else{
    console.log("그런 달은 없습니다.");
}


//형변환  = 데이터타입을 변환
let weight = 70.30;
console.log(weight);
//정수부만 뽑으려고 하면 어떻게할까? 
console.log(Math.floor(weight));


// 문자열을 변수로 줄건데 그 문자열의 길이가 10이 넘으면 길다.
// 5~10사이면 보통
// 0~4사이면 짧다.
// 라고 표현해보세요.
let sentence = "동해물과 백두산이";
let size = sentence.length;
if(0<= size && size <=4){
    console.log("짧다.");
}else if(5<= size && size <= 10){
    console.log("보통");
}else{
    console.log("길다.");
}


//조건문
//1. 삼항     2. if     3. switch

console.log(5%2==1? '홀수' : '짝수');
//응용. 타입이 number인지 그외인지 삼항연산자로 판별

//3. switch
let sum = '미';
switch(sum){
    case '수':
        console.log("90점 이상입니다.");
        break;  //더이상 다른 case문을 실행시키지 않음
    case '우':
        console.log("80점 이상입니다.");
        break;
    case '미':
        console.log("70점 이상입니다.");
        break;
    case '양':
        console.log("60점 이상입니다.");
        break;
    case '가':
        console.log("50점 이상입니다.");
        break;
}

//점수를 입력받고 
// 50점이상이면 '가'를 출력
// ...
// 80점 이상이면 '우'를 출력
// 90점이상이면 '수'를 출력
// -> 80~89까지 우. 십의수만 필요하다.

let score = 82;
let scoreTen = parseInt(score/10);
switch(scoreTen){
    case 9:
        console.log("수");
        break;
    case 8:
        console.log("우");
        break;
    case 7:
        console.log("미");
        break;
    case 6:
        console.log("양");
        break;
    case 5:
        console.log("가");
        break;
}


//반복문
// 1. for   2. while   3. do-while



//함수